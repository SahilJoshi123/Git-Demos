import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-book',
  templateUrl: './book.component.html',
  styleUrls: ['./book.component.css']
})
export class BookComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  selectedItems: number =0;
  counter: number = 0;
  limit: number = 3;
  checkedState(event, checkBox) {
            if(event.target.checked === true){
              if(this.counter < this.limit){
              this.counter++
            }else{
               event.target.checked = false;
            }
            }else if(this.counter>0){
              this.counter--;
            }
        }
}
